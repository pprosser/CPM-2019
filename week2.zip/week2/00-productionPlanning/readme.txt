Production Planning
-------------------
We have to make products, given a supply of commodities/materials/resources. 
Each product has a demand for these commodities/materials/resources.
We have a given supply of each commodity/material/resource.
Each product has a given value.

We have an optimization problem "Maximize the value of production" and a 
decision problem "Can you meet the production target V?"

This is a real problem. The products may be "hard/tangible" things such as 
cars, phones, food etc. They might also be "soft" such as a services. A product
might even be software! And the commodities/materials/resources might be metals,
people-hours, energy, pollutants (CO2), ...

Who cares? Who cares about production planning? At what point might an endeavour
actually start planning production?

NOTE: what assumptions are we making about demand for our products?
      might we insist that there be a minimum quantity for our products?
      As above, but maximum quantities (don't over produce)

NOTE: consider the "planned economies" with nationalised industies: coal, gas,
      electricity, oil (BNOC/BRITOIL), rail, steel, milk, post office, ...
      Think of Kantarovich (spelling?) and "Red Plenty". National planning
      was rejected based on early 70's models of computation, although some
      hydraulic models existed.

NOTE: it is assumed that we can measure accurately. Is that a fair assumption?
      Think of project costs: buildings, roads, aircraft, software, ... BL and Mini

In this example look at computational costs of finding and proving optimality
via the optimization model and then via a sequence of decision problems.

Do we notice anything interesting with respect to finding optimal and proving optimal?
Are all problems hard?

FOR YOU: go have a look at production planning, start at the wiki page, go look at
history, look at production planning software and companies that provide these.
Is production planning a big deal, i.e. who cares? Have a look at SATALIA, ILOG 
at IBM, ... Is optimization the next "big thing"?

CONSIDER THIS: how adaptable is our model? What if we were to produce more
spears than swords? What changes would we make to the model?

WHAT HAVE WE LEARNED?
1. An important problem
2. Relationship between decision & optimisation problem
3. Empirical appreciation of (2) above
4. A simple mathematical/constraint model
5. Parameter setting on command line
6. forall and sum constraints


Patrick