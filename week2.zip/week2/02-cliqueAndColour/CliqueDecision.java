import java.util.*;
import java.io.*;

public class CliqueDecision {

    static int[] degree;   // degree of vertices
    static int[][] A;      // 0/1 adjacency matrix
    static int n;

    static void readDIMACS(String fname) throws IOException {
	String s = "";
	Scanner sc = new Scanner(new File(fname));
	while (sc.hasNext() && !s.equals("p")) s = sc.next();
	sc.next();
	n      = sc.nextInt();   
	int m  = sc.nextInt();   
	degree = new int[n];
	A      = new int[n][n];
	while (sc.hasNext()){
	    s     = sc.next(); // skip "edge"
	    int i = sc.nextInt() - 1;
	    int j = sc.nextInt() - 1; 
	    degree[i]++; degree[j]++;
	    A[i][j] = A[j][i] = 1;
	}
	sc.close();
    }

    public static void main(String[] args)  throws IOException {

	readDIMACS(args[0]);
	int k = Integer.parseInt(args[1]);
	CD cd = new CD(n,A,degree,k);
	long cpuTime = System.currentTimeMillis();
	cd.search();
	cpuTime = System.currentTimeMillis() - cpuTime;
	System.out.println(k +"-clique? "+ cd.found +"  nodes: "+ cd.nodes +" time: "+ cpuTime);
	//for (int i=0;i<=k;i++) System.out.print(cd.visits[i] +" ");
	System.out.println();
    }
}
