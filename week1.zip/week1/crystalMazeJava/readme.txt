Crystal Maze, coded up raw in java.

Algorithm is BT, i.e. backward checking chronological backtracker

0. Show how it goes
   - show code
   - mention that this is "a decision problem"
   - are all problems solvable?

1. back-checking and backtracking
   - show back-checking (no filtering)
   - show chronological backtracking (dumb)

2. We can use an arbitrary graph as input
   - show how we can generate a random graph
   - show run time behaviour as we vary edge probability
   - answer question "are all problems solvable"?

3. Would we have to write another piece of code for another problem,
   different but similar?

4. Comments on my coding style.


Patrick (December 2018)
