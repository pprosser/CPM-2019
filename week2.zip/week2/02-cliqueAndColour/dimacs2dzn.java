import java.util.*;
import java.io.*;

public class dimacs2dzn {

    static int[] degree;   // degree of vertices
    static int[][] A;      // 0/1 adjacency matrix
    static int n;

    static void readDIMACS(String fname) throws IOException {
	String s = "";
	Scanner sc = new Scanner(new File(fname));
	while (sc.hasNext() && !s.equals("p")) s = sc.next();
	sc.next();
	n      = sc.nextInt();   
	int m  = sc.nextInt();   
	degree = new int[n];
	A      = new int[n][n];
	while (sc.hasNext()){
	    s     = sc.next(); // skip "edge"
	    int i = sc.nextInt() - 1;
	    int j = sc.nextInt() - 1; 
	    degree[i]++; degree[j]++;
	    A[i][j] = A[j][i] = 1;
	}
	sc.close();
    }

    public static void main(String[] args)  throws IOException {

	readDIMACS(args[0]);
	System.out.println("n = "+ n +";");
	System.out.print("A = [|"+ A[0][0]);
	for (int j=1;j<n;j++) System.out.print(","+ A[0][j]);
	for (int i=1;i<n;i++){
	    System.out.println();
	    System.out.print("     |"+ A[i][0]);
	    for (int j=1;j<n;j++) System.out.print(","+ A[i][j]);
	}
	System.out.println("|];");
    }
}
	    
