import java.util.*;
import java.io.*;	

public class toDzn { 	
  
    public static void main(String[] args) throws Exception {
	Scanner sc = new Scanner(new File(args[0]));
	int n = sc.nextInt();
	boolean[][]adjacent = new boolean[n][n];
	int m = 0;
	while (sc.hasNext()){	  
	    int i = sc.nextInt();
	    int j = sc.nextInt(); 
	    adjacent[i][j] = adjacent[j][i] = true;
	    m++;
	}
	sc.close();
	System.out.println("n = "+ n +";");
	System.out.println("m = "+ m +";");
	System.out.print("edge = [");
	for (int i=0;i<n-1;i++)
	    for (int j = i+1;j<n;j++)
		if (adjacent[i][j])
		    System.out.println("|"+ i +","+ j);
	System.out.println("|];");
    }
}

	
