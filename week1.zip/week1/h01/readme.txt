
      Power Set and Patterned Output
      -------------------------------
	  
Power Set (PS)
--------------
Write a small program, PS, that takes on the command line as input an integer
and then outputs the power set of the set {0..n-1}. For example with input 3 we get

> mzn-gecode ps -D"n=3" -a
v = 1..3;
----------
v = 1..2;
----------
v = {1,3};
----------
v = 1..1;
----------
v = 2..3;
----------
v = 2..2;
----------
v = 3..3;
----------
v = {};
----------
==========

NOTE: you should use set variables, i.e. 

     var set of lwb..upb: nameOfSet;


Pattern
-------
Write a program, pattern.mzn, that takes as input on the command line the 
integers n and m, where 0 <= m <= 9, and outputs an n digit number (where digits 
are in the range 0..m) that is right-filled with zeros and the digit in position 
i is greater than the digit in position i+1. For example with n=3 and m=4 we get

> mzn-gecode pattern.mzn -D"n=3;m=4;" -a

v = array1d(1..3 ,[0, 0, 0]);
----------
v = array1d(1..3 ,[1, 0, 0]);
----------
v = array1d(1..3 ,[2, 0, 0]);
----------
v = array1d(1..3 ,[3, 0, 0]);
----------
v = array1d(1..3 ,[4, 0, 0]);
----------
v = array1d(1..3 ,[2, 1, 0]);
----------
v = array1d(1..3 ,[3, 1, 0]);
----------
v = array1d(1..3 ,[4, 1, 0]);
----------
v = array1d(1..3 ,[3, 2, 0]);
----------
v = array1d(1..3 ,[4, 2, 0]);
----------
v = array1d(1..3 ,[4, 3, 0]);
----------
v = array1d(1..3 ,[3, 2, 1]);
----------
v = array1d(1..3 ,[4, 2, 1]);
----------
v = array1d(1..3 ,[4, 3, 1]);
----------
v = array1d(1..3 ,[4, 3, 2]);
----------
==========

NOTE: (a) look at the "if then else endif" constraint, section 3.3. of tutorial
      (b) you might use an array of constrained integer variables to represent
          the pattern, such that pattern[i] is the value in the ith position


Patrick