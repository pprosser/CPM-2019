

Part A:
  Take as input integers n and r and output all r-combinations of integers 1 to n

> mzn-gecode comb.mzn -D"n=5;r=2;" -a


Part B:
  Take as input integers n and r and output all r-permutations of integers 1 to n

> mzn-gecode perm.mzn -D"n=4;r=3;" -a

see sample outputs

Patrick