Write a minizinc program that takes as argument a file name corresponding
to a Crystal Maze problem. The program then models and solves that problem. 

Answer the following questions:

(a) Using the neq binary constraint is the problem solved in propagation alone?

(b) Produce two versions, one to find and display a solution, one to count solutions.

(c) try it on bigger instances

NOTE: cm8
    
       1    2  
  0    6    7   3
       5    4

  
