Graph colouring, two perspectives

 - colour vertices
 - place vertices in colour classes

P


