import java.util.*;
import java.io.*;

public class CrystalMaze {

    int n;
    long nodes, checks;
    boolean[][] adjacent;
    int[] v; // v[i] is value assigned to the vertex v[i]
    
    CrystalMaze(String fname) throws IOException {
	Scanner sc = new Scanner(new File(fname));
	n = sc.nextInt();
	adjacent = new boolean[n][n];
	v = new int[n];
	while (sc.hasNext()){	  
	    int i = sc.nextInt();
	    int j = sc.nextInt(); 
	    adjacent[i][j] = adjacent[j][i] = true;
	}
	sc.close();
    }

    boolean consistent(int i,int j){
	checks++;
	return v[i] != v[j] &&
	    (!adjacent[i][j] || adjacent[i][j] && Math.abs(v[i] - v[j]) > 1);
    }
    //
    // Is v[i] consistent with v[j]?
    //
    
    boolean solve(){
	return expand(0);
    }

    boolean expand(int i){	
	if (i == n) return true; // everything assigned
	nodes++;
	boolean consistent = false;
	for (int j=0;j<n && !consistent;j++){ // find a consistent value j for v[i]
	    consistent = true;
	    v[i] = j;
	    for (int k=0;k<i && consistent;k++) // check backwards against current instantiations
		 consistent = consistent(i,k);
	    consistent = consistent && expand(i+1);
	}
	return consistent;
    }
    //
    // A backward checking chronological backtracker ... BT
    //

    void stats(){
	System.out.println("nodes: "+ nodes +"  checks: "+ checks);
    }

     public static void main(String[] args)  throws IOException {
	 
	CrystalMaze cm = new CrystalMaze(args[0]);
	if (cm.solve()){
	    for (int i=0;i<cm.n;i++) System.out.print(cm.v[i] +" ");
	    System.out.println();
	}
	cm.stats();
    }
}
