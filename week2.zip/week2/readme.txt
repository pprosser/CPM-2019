A lecture plan for Tuesday 15th might be as follows

12:00
--------
production planning problem: optimisation and decision problem. What happens as we approach unsat.
 
rota for security guards: gradually improving models (4 versions), introduces cardinality constraint 
and lex constraint (symmetry breaker), computing a lower bound ... decision and optimisation

15:00 and beyond
---------------------------
clique and colour: simple & elegant models ... might not lead to efficient design! Relationship between 
omega and chi.

ex01: present problem and thumbnail sketch of two perspectives ("what team am I in?" v "who's in this team?")

small tsp: because it's a gas ... but small & elegant model might only work for small easy problems.