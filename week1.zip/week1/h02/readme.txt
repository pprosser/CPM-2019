
Part A:
 Select 75 integers between 1 and 230 (inclusive) such that no
 two of them differ by exactly 5, 6, or 11.

> mzn-gecode numberPuzzle.mzn -D"n=20;" 
v = array1d(1..20 ,[53, 52, 51, 50, 49, 37, 36, 35, 34, 33, 21, 20, 19, 18, 17, 5, 4, 3, 2, 1]);
----------

NOTE: you might use an array of n constrained integer variables with domains 1 to 230,
      the all_different constraint, and constraints to ensure that the absolute difference
      between any two variables is not 5, 6 or 11


Part B:
 Show that one cannot select 76 integers satisfying the same requirements