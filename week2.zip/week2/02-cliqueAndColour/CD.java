import java.util.*;

public class CD {
    int[] degree;   // degree of vertices
    int[][] A;      // 0/1 adjacency matrix
    int n;          // n vertices
    long nodes;     // number of decisions
    long timeLimit; // milliseconds
    long cpuTime;   // milliseconds
    int style;      // used to flavor algorithm
    int k;          // size of clique to find
    boolean found;  // true if clique of size k found
    int[] visits;   // visits at depth

    CD (int n,int[][]A,int[] degree,int k) {
	this.n = n;
	this.A = A;
	this.degree = degree;
	nodes = 0;
	cpuTime = timeLimit = -1;
	style = 1;
	visits = new int[n];
	this.k = k;
    }

    void search(){
	cpuTime              = System.currentTimeMillis();
	nodes                = 0;
	ArrayList<Integer> C = new ArrayList<Integer>();
	ArrayList<Integer> P = new ArrayList<Integer>(n);
	for (int i=0;i<n;i++) P.add(i);
	found = expand(C,P);
    }

    boolean expand(ArrayList<Integer> C,ArrayList<Integer> P){
	if (timeLimit > 0 && System.currentTimeMillis() - cpuTime >= timeLimit) return false;
	nodes++;
	visits[C.size()]++;
	boolean found = C.size() == k;
	while (!found && C.size() + P.size() >= k){
	    int v = select(P);
	    C.add(v);
	    ArrayList<Integer> newP = new ArrayList<Integer>();
	    for (int w : P) if (A[v][w] == 1) newP.add(w);
	    found = expand(C,newP);
	    C.remove((Integer)v);
	    P.remove((Integer)v);
	}
	return found;
    }

    int select(ArrayList<Integer> P){
	return P.get(P.size()-1);
    }

}
