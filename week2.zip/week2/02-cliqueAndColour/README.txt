When using windows 10 power shell, redirected output via > transoforms
text to unicode when it should be in ascii. Therefore ...

DO NOT DO THIS

   java RandomGraph 10 0.5 > 10-50-00.txt

DO THIS

   java RandomGraph 10 0.5 | out-file 10-50-00.txt -encoding ASCII

---

Setting parameters on command line ... example

   mzn-gecode clique.mzn 05-60.dzn -D"k=3"

to find a clique of size 3 in graph 05-06

---

toDo ... do the toDo in toDo.txt


23/10/2017
